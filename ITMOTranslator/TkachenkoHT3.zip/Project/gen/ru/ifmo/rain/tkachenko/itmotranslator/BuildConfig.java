/** Automatically generated file. DO NOT MODIFY */
package ru.ifmo.rain.tkachenko.itmotranslator;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}